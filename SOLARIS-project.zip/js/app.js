import {bodies,order,translations} from "./data.js";
import {initSolar3D} from "./scene3d.js";

let lang="fa", selected="earth", activeFilter="all", paused=false;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const t=k=>translations[lang][k]||k;
const name=id=>bodies[id].name[lang];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

function setLanguage(next){
  lang=next;document.documentElement.lang=lang;document.documentElement.dir=lang==="fa"?"rtl":"ltr";
  $("#langToggle").textContent=lang==="fa"?"EN":"فا";
  $$("[data-i18n]").forEach(el=>{const key=el.dataset.i18n;if(translations[lang][key]!==undefined)el.innerHTML=translations[lang][key]});
  $$("[data-i18n-placeholder]").forEach(el=>el.placeholder=t(el.dataset.i18nPlaceholder));
  renderPlanet(selected);renderGrid();renderSelector();populateGravity();
  $("#orbitToggle span:last-child").textContent=paused?t("resumeMotion"):t("pauseMotion");
}
function planetMarkup(id){const b=bodies[id];return `<div class="card-orb ${id}"></div>`}
function renderPlanet(id){
  selected=id;const b=bodies[id];
  $("#planetCode").textContent=`${lang==="fa"?"سیاره":"PLANET"} / ${b.id}`;
  $("#planetType").textContent=b.type[lang].toUpperCase();$("#planetName").textContent=name(id);
  $("#planetSymbol").textContent=b.symbol;$("#planetSummary").textContent=b.summary[lang];
  $("#statDiameter").textContent=b.diameter;$("#statDay").textContent=b.day;$("#statYear").textContent=b.year;$("#statMoons").textContent=b.moons;
  $("#planetVisual").innerHTML=`<div class="visual-orb ${id}-orb"></div>`;
  $$(".stage-planet").forEach(p=>p.classList.toggle("selected",p.dataset.planet===id));
  $$(".selector-chip").forEach(p=>p.classList.toggle("active",p.dataset.planet===id));
}
function renderSelector(){
  $("#planetSelector").innerHTML=order.filter(id=>id!=="pluto").map(id=>`<button class="selector-chip ${id===selected?"active":""}" data-planet="${id}">${esc(name(id))}</button>`).join("");
  $$(".selector-chip").forEach(btn=>btn.addEventListener("click",()=>renderPlanet(btn.dataset.planet)));
}
function renderGrid(){
  const query=$("#catalogSearch").value.trim().toLocaleLowerCase();
  const ids=order.filter(id=>{
    const b=bodies[id], matchFilter=activeFilter==="all"||b.kind===activeFilter;
    const matchQuery=!query||[b.name.fa,b.name.en,b.summary.fa,b.summary.en].join(" ").toLocaleLowerCase().includes(query);
    return matchFilter&&matchQuery;
  });
  $("#planetGrid").innerHTML=ids.length?ids.map(id=>{const b=bodies[id];return `<article class="planet-card" tabindex="0" role="button" data-card="${id}" aria-label="${esc(name(id))}"><div class="planet-card-top"><span>${b.id} / ${b.type[lang].toUpperCase()}</span><span>↗</span></div><div class="card-orb-wrap">${planetMarkup(id)}</div><h3>${esc(name(id))}</h3><p>${esc(b.description[lang])}</p><span class="card-arrow">↗</span></article>`}).join(""):`<p class="empty-state">${t("emptySearch")}</p>`;
  $$("[data-card]").forEach(card=>{const open=()=>{renderPlanet(card.dataset.card);openDossier(card.dataset.card)};card.addEventListener("click",open);card.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open()}})});
}
function openDossier(id){
  const b=bodies[id];$("#dialogCode").textContent=`BODY / ${b.id}`;$("#dialogType").textContent=b.type[lang].toUpperCase();$("#dialogName").textContent=name(id);$("#dialogSymbol").textContent=b.symbol;
  $("#dialogDescription").textContent=b.description[lang];$("#dialogScience").textContent=b.science[lang];$("#dialogPlanetArt").innerHTML=planetMarkup(id);
  const stats=[["DIAMETER",b.diameter],["ROTATION",b.day],["ORBIT",b.year],["MOONS",b.moons],["GRAVITY",`${b.gravity.toFixed(2)} m/s²`],["DISTANCE",`${b.au} AU`]];
  $("#dialogStats").innerHTML=stats.map(([k,v])=>`<div class="dialog-stat"><small>${k}</small><b>${v}</b></div>`).join("");
  $("#dossierDialog").showModal();
}
function populateGravity(){
  const select=$("#gravitySelect"),previous=select.value||"earth";
  select.innerHTML=order.map(id=>`<option value="${id}">${name(id)}</option>`).join("");
  select.value=bodies[previous]?previous:"earth";updateWeight();
}
function updateWeight(){
  const mass=Number($("#massSlider").value),body=bodies[$("#gravitySelect").value];
  $("#massValue").textContent=mass;$("#weightResult").innerHTML=`${(mass*body.gravity).toFixed(1)} <i>N</i>`;
}
function updateOrbit(){
  const altitude=Number($("#altitudeSlider").value),earthRadius=6371,mu=398600.4418;
  const speed=Math.sqrt(mu/(earthRadius+altitude));
  $("#altitudeValue").textContent=altitude.toLocaleString(lang==="fa"?"fa-IR":"en-US");
  $("#speedResult").innerHTML=`${speed.toFixed(2)} <i>km/s</i>`;
}
function showToast(message){const toast=$("#toast");toast.textContent=message;toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),2300)}
function setupEvents(){
  $("#langToggle").addEventListener("click",()=>setLanguage(lang==="fa"?"en":"fa"));
  $("#menuToggle").addEventListener("click",()=>$(".main-nav").classList.toggle("open"));
  $$(".main-nav a").forEach(a=>a.addEventListener("click",()=>$(".main-nav").classList.remove("open")));
  $$(".stage-planet").forEach(p=>p.addEventListener("click",()=>renderPlanet(p.dataset.planet)));
  $("#planetDetails").addEventListener("click",()=>openDossier(selected));
  $("#dialogClose").addEventListener("click",()=>$("#dossierDialog").close());
  $("#dossierDialog").addEventListener("click",e=>{if(e.target===$("#dossierDialog"))$("#dossierDialog").close()});
  $("#orbitToggle").addEventListener("click",()=>{
    paused=!paused;$$(".stage-orbit").forEach(o=>o.classList.toggle("paused",paused));
    $("#orbitToggle span:first-child").textContent=paused?"▶":"Ⅱ";$("#orbitToggle span:last-child").textContent=paused?t("resumeMotion"):t("pauseMotion");
  });
  $("#massSlider").addEventListener("input",updateWeight);$("#gravitySelect").addEventListener("change",updateWeight);
  $("#altitudeSlider").addEventListener("input",updateOrbit);
  $("#catalogSearch").addEventListener("input",renderGrid);
  $$(".filter-tab").forEach(btn=>btn.addEventListener("click",()=>{$$(".filter-tab").forEach(b=>b.classList.remove("active"));btn.classList.add("active");activeFilter=btn.dataset.filter;renderGrid()}));
  $("#soundToggle").addEventListener("click",()=>showToast(lang==="fa"?"صدای محیط در نسخه بعدی اضافه می‌شود.":"Ambient audio is planned for a future version."));
}
function init(){
  setupEvents();setLanguage("fa");updateOrbit();renderPlanet("earth");renderGrid();renderSelector();populateGravity();
  try{
    const scene=initSolar3D($("#solar3d"),id=>renderPlanet(id));
    $(".solar-stage").classList.add("webgl-ready");
    $("#orbitToggle").addEventListener("click",()=>paused?scene.resume():scene.pause());
  }catch(error){console.info("WebGL unavailable; using the CSS orbital model.",error);}
}
init();