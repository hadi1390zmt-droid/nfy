import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";
import { OrbitControls } from "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/controls/OrbitControls.js";

const specs=[
 ["mercury",3.9,0.16,0xb1a99c,0.24],["venus",5.2,0.25,0xd6a56d,0.62],
 ["earth",6.7,0.27,0x3f91cf,1.0],["mars",8.3,0.21,0xc56b4e,1.88],
 ["jupiter",11.3,0.72,0xc69a76,11.86],["saturn",14.5,0.61,0xcdbb91,29.45],
 ["uranus",17.4,0.43,0x8ed4d9,84],["neptune",20,0.42,0x416fc9,164.8]
];
export function initSolar3D(canvas,onSelect){
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(43,1,.1,200);
  camera.position.set(0,13,27);
  const renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio,2));
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  const controls=new OrbitControls(camera,renderer.domElement);
  controls.enableDamping=true;controls.dampingFactor=.045;controls.minDistance=12;controls.maxDistance=48;
  controls.target.set(0,0,0);
  scene.add(new THREE.AmbientLight(0x9cb8d8,.7));
  const sunLight=new THREE.PointLight(0xffd39a,210,90,1.6);scene.add(sunLight);
  const sun=new THREE.Mesh(new THREE.SphereGeometry(.95,48,32),new THREE.MeshBasicMaterial({color:0xffbd69}));
  scene.add(sun);
  const sunHalo=new THREE.Mesh(new THREE.SphereGeometry(1.2,32,24),new THREE.MeshBasicMaterial({color:0xff9d4d,transparent:true,opacity:.10,side:THREE.BackSide}));
  scene.add(sunHalo);
  const starGeo=new THREE.BufferGeometry(),starCount=1000,positions=new Float32Array(starCount*3);
  for(let i=0;i<starCount;i++){positions[i*3]=(Math.random()-.5)*90;positions[i*3+1]=(Math.random()-.5)*55;positions[i*3+2]=(Math.random()-.5)*90;}
  starGeo.setAttribute("position",new THREE.BufferAttribute(positions,3));
  scene.add(new THREE.Points(starGeo,new THREE.PointsMaterial({color:0xaac8e8,size:.055,transparent:true,opacity:.8})));
  const objects=[];
  for(const [id,radius,size,color,period] of specs){
    const orbit=new THREE.Mesh(new THREE.RingGeometry(radius-.008,radius+.008,160),new THREE.MeshBasicMaterial({color:0x6284a6,side:THREE.DoubleSide,transparent:true,opacity:.35}));
    orbit.rotation.x=-Math.PI/2;scene.add(orbit);
    const material=new THREE.MeshStandardMaterial({color,roughness:.88,metalness:.02});
    const mesh=new THREE.Mesh(new THREE.SphereGeometry(size,32,24),material);
    mesh.userData={id,radius,period,phase:Math.random()*Math.PI*2};
    scene.add(mesh);objects.push(mesh);
    if(id==="saturn"){
      const ring=new THREE.Mesh(new THREE.RingGeometry(size*1.35,size*2.0,64),new THREE.MeshStandardMaterial({color:0xc6b58e,side:THREE.DoubleSide,transparent:true,opacity:.75}));
      ring.rotation.x=-Math.PI/2.7;mesh.add(ring);
    }
  }
  const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
  canvas.addEventListener("click",e=>{
    const rect=canvas.getBoundingClientRect();pointer.x=((e.clientX-rect.left)/rect.width)*2-1;pointer.y=-((e.clientY-rect.top)/rect.height)*2+1;
    raycaster.setFromCamera(pointer,camera);const hits=raycaster.intersectObjects(objects);
    if(hits.length&&onSelect)onSelect(hits[0].object.userData.id);
  });
  let running=true,frame=0;
  const resize=()=>{const w=canvas.clientWidth,h=canvas.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();};
  const observer=new ResizeObserver(resize);observer.observe(canvas);resize();
  const animate=()=>{
    if(!running)return;frame=requestAnimationFrame(animate);
    const time=performance.now()*.00012;
    objects.forEach(mesh=>{const d=mesh.userData,rate=1/Math.sqrt(d.period);const a=time*rate*9+d.phase;mesh.position.set(Math.cos(a)*d.radius,0,Math.sin(a)*d.radius);mesh.rotation.y+=.002;});
    sun.rotation.y+=.001;controls.update();renderer.render(scene,camera);
  };animate();
  return {pause(){running=false;cancelAnimationFrame(frame)},resume(){if(!running){running=true;animate()}},dispose(){running=false;observer.disconnect();renderer.dispose();}};
}
